-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: sql113.infinityfree.com
-- Generation Time: Jul 28, 2026 at 11:50 AM
-- Server version: 11.4.12-MariaDB
-- PHP Version: 7.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `if0_42314235_pojokdesa`
--

-- --------------------------------------------------------

--
-- Table structure for table `agenda`
--

CREATE TABLE `agenda` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `judul` varchar(255) NOT NULL,
  `tanggal` date NOT NULL,
  `jam` varchar(255) DEFAULT NULL,
  `lokasi` varchar(255) DEFAULT NULL,
  `kategori` varchar(255) DEFAULT NULL,
  `deskripsi` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `anggota_kkn`
--

CREATE TABLE `anggota_kkn` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nama` varchar(255) NOT NULL,
  `prodi` varchar(255) NOT NULL,
  `fakultas` varchar(255) NOT NULL,
  `posisi` varchar(255) NOT NULL,
  `foto` text DEFAULT NULL,
  `nim` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `anggota_kkn`
--

INSERT INTO `anggota_kkn` (`id`, `nama`, `prodi`, `fakultas`, `posisi`, `foto`, `nim`, `created_at`, `updated_at`) VALUES
(6, 'Muhammad Pin Ping Anugerah Hariah Tama Putra', 'Teknik Sipil', 'Teknik', 'Ketua', 'uploads/kkn/PyQgmDY5kNYqz6H6kLECfHDppKI8v8VylLhYe3aI.jpg', 'G1B023087', '2026-07-04 05:21:21', '2026-07-04 06:21:24'),
(7, 'Reffki Andrea Pratama', 'Informatika', 'Teknik', 'PDK', 'uploads/kkn/tftsdfTuOra7Qg6iDcYL1b9DzTihK5rZq4VPourP.jpg', 'G1A023039', '2026-07-04 05:25:48', '2026-07-04 06:22:52'),
(8, 'Rezi Nopitri Yadi', 'Peternakan', 'Pertanian', 'Humas', 'uploads/kkn/NokS7U0c6sA15nXL2Omy5CHf190GiTZ1lfp2xg2v.jpg', 'E1C023048', '2026-07-04 05:30:13', '2026-07-04 06:27:31'),
(9, 'Maulana Ahmad Danill', 'Ekonomi Pembangunan', 'Ekonomi dan Bisnis', 'Humas', 'uploads/kkn/Jf7nLuGS4HUgW7bd7ZZcDwcdDr6wS9an9TbJr55I.jpg', 'CIA023063', '2026-07-04 05:32:37', '2026-07-04 06:27:50'),
(10, 'Revina Anggraeni', 'Pendidikan Bahasa Indonesia', 'Keguruan dan Ilmu Pendidikan', 'Sekretaris', 'uploads/kkn/he7UZ0iqNfyKgbYMa5HPkXsdjVOkJc720FB3b5ko.jpg', 'A1A023051', '2026-07-04 05:34:29', '2026-07-04 06:28:09'),
(11, 'Ferlin Fernandes', 'Perpustakaan dan Sains', 'Ilmu Sosial dan Ilmu Politik', 'PDK', 'uploads/kkn/FIymGIBhnK63fcFBOIYtC9AmoQkGNO9CDHrQ9M7U.jpg', 'D1B023062', '2026-07-04 05:36:03', '2026-07-04 06:28:34'),
(12, 'Hafizhah Khairannisa', 'Ilmu Hukum', 'Hukum', 'Acara', 'uploads/kkn/TgPXBktJjayz6JKUTG6XBtvnayB6AS4cXuAIASQW.jpg', 'BIA023221', '2026-07-04 05:38:05', '2026-07-04 06:29:28'),
(13, 'Bella Alfia', 'Manajemen', 'Ekonomi dan Bisnis', 'Bendahara', 'uploads/kkn/owiAzJmYNjYgrKQWDWYMbS2lB1JufByueEZVUuAz.jpg', 'C1B023105', '2026-07-04 05:39:11', '2026-07-04 06:29:43');

-- --------------------------------------------------------

--
-- Table structure for table `aspirasi`
--

CREATE TABLE `aspirasi` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nama` varchar(255) NOT NULL,
  `kategori` varchar(255) NOT NULL,
  `pesan` text NOT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'diterima',
  `balasan` text DEFAULT NULL,
  `anonim` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `aspirasi`
--

INSERT INTO `aspirasi` (`id`, `nama`, `kategori`, `pesan`, `status`, `balasan`, `anonim`, `created_at`, `updated_at`) VALUES
(1, 'kuku', 'Infrastruktur', 'Tes', 'diterima', NULL, 0, '2026-07-05 19:17:51', '2026-07-05 19:17:51');

-- --------------------------------------------------------

--
-- Table structure for table `berita`
--

CREATE TABLE `berita` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `judul` varchar(255) NOT NULL,
  `kategori` varchar(255) NOT NULL,
  `tanggal` date NOT NULL,
  `penulis` varchar(255) NOT NULL,
  `foto` text DEFAULT NULL,
  `ringkasan` text NOT NULL,
  `konten` longtext NOT NULL,
  `views` int(11) NOT NULL DEFAULT 0,
  `published` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `berita`
--

INSERT INTO `berita` (`id`, `judul`, `kategori`, `tanggal`, `penulis`, `foto`, `ringkasan`, `konten`, `views`, `published`, `created_at`, `updated_at`) VALUES
(2, 'Tim KKN Periode 108 Kelompok 146 Resmi Bertugas', 'KKN', '2025-06-17', 'Tim KKN', 'https://images.unsplash.com/photo-1523240795612-9a054b0db644?w=600', 'Mahasiswa KKN Universitas Bengkulu Periode 108 Kelompok 146 resmi memulai pengabdian mereka di Desa Talang Marap.', 'Sebanyak 10 mahasiswa dari berbagai fakultas di Universitas Bengkulu siap mengabdi dan berkontribusi dalam pembangunan Desa Talang Marap selama 40 hari ke depan.', 413, 1, '2026-06-23 03:42:27', '2026-07-04 04:28:12');

-- --------------------------------------------------------

--
-- Table structure for table `dokumen`
--

CREATE TABLE `dokumen` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nama` varchar(255) NOT NULL,
  `kategori` varchar(255) NOT NULL,
  `tanggal` date DEFAULT NULL,
  `ukuran` varchar(255) DEFAULT NULL,
  `tipe` varchar(255) DEFAULT NULL,
  `url` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `dokumen`
--

INSERT INTO `dokumen` (`id`, `nama`, `kategori`, `tanggal`, `ukuran`, `tipe`, `url`, `created_at`, `updated_at`) VALUES
(1, 'RPJMDes 2020-2025', 'Perencanaan', '2020-01-15', '2.4 MB', 'PDF', NULL, '2026-06-23 03:42:28', '2026-06-23 03:42:28'),
(2, 'APBDes 2025', 'Keuangan', '2025-01-10', '1.8 MB', 'PDF', NULL, '2026-06-23 03:42:28', '2026-06-23 03:42:28'),
(3, 'Monografi Desa 2024', 'Profil', '2024-12-31', '3.2 MB', 'PDF', NULL, '2026-06-23 03:42:28', '2026-06-23 03:42:28'),
(4, 'Peraturan Desa No.1/2025', 'Peraturan', '2025-03-01', '0.8 MB', 'PDF', NULL, '2026-06-23 03:42:28', '2026-06-23 03:42:28');

-- --------------------------------------------------------

--
-- Table structure for table `galeri`
--

CREATE TABLE `galeri` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `judul` varchar(255) NOT NULL,
  `kategori` varchar(255) NOT NULL,
  `foto` text NOT NULL,
  `tanggal` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `galeri`
--

INSERT INTO `galeri` (`id`, `judul`, `kategori`, `foto`, `tanggal`, `created_at`, `updated_at`) VALUES
(7, 'kkn146', 'Kegiatan', 'uploads/galeri/3SYCEhLZwCzXaCsIs6geAFdT21NQh8PHZSz9v2iB.jpg', '2026-06-28', '2026-07-04 06:43:26', '2026-07-04 06:43:26');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(2, '2024_01_01_000001_create_all_tables', 1),
(3, '2024_01_02_000001_create_peta_rumah_table', 2),
(4, '2026_06_27_000001_add_role_to_users_table', 3),
(5, '2026_06_27_000002_add_email_verification_to_users_table', 4);

-- --------------------------------------------------------

--
-- Table structure for table `pengaturan`
--

CREATE TABLE `pengaturan` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `key` varchar(255) NOT NULL,
  `value` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pengaturan`
--

INSERT INTO `pengaturan` (`id`, `key`, `value`, `created_at`, `updated_at`) VALUES
(1, 'nama_desa', 'Desa Talang Marap', '2026-06-23 03:42:26', '2026-06-23 03:42:26'),
(2, 'kecamatan', 'Kecamatan Kelam Tengah', '2026-06-23 03:42:26', '2026-06-23 03:42:26'),
(3, 'kabupaten', 'Kabupaten Kaur', '2026-06-23 03:42:26', '2026-06-23 03:42:26'),
(4, 'provinsi', 'Provinsi Bengkulu', '2026-06-23 03:42:26', '2026-06-23 03:42:26'),
(5, 'tagline', 'Mengenal Desa, Mengelola Data, Membangun Masa Depan', '2026-06-23 03:42:26', '2026-06-23 03:42:26'),
(9, 'alamat', 'Jl. Raya Talang Marap No. 1, Kec. Kelam Tengah, Kab. Kaur', '2026-06-23 03:42:26', '2026-06-23 03:42:26'),
(10, 'jam_operasional', 'Senin - Jumat: 08.00 - 16.00 WIB', '2026-06-23 03:42:27', '2026-06-23 03:42:27'),
(11, 'instagram', 'desatalangmarap', '2026-06-23 03:42:27', '2026-06-23 03:42:27'),
(12, 'facebook', 'Desa Talang Marap', '2026-06-23 03:42:27', '2026-06-23 03:42:27'),
(13, 'tiktok', '@desatalangmarap', '2026-06-23 03:42:27', '2026-06-23 03:42:27'),
(14, 'youtube', 'Portal Desa Talang Marap', '2026-06-23 03:42:27', '2026-06-23 03:42:27'),
(19, 'maps_desa', 'https://www.google.com/maps?q=-4.35,103.12', '2026-06-23 03:42:27', '2026-06-23 03:42:27'),
(20, 'koordinat_desa', '-4.573516, 103.207076', '2026-06-23 03:42:27', '2026-07-14 16:30:19'),
(25, 'logo', 'uploads/logo/Ce5eYwIMAxrCdl2WaSWt0ihLBNcKUzM1c15JVjjg.jpg', '2026-07-08 15:58:38', '2026-07-08 15:58:38'),
(26, 'kepala_desa', 'Midarman', NULL, NULL),
(27, 'whatsapp', '6282350257688', NULL, NULL),
(28, 'email', 'desatalangmarap1@gmail.com', NULL, NULL),
(29, 'jumlah_kk', '211', NULL, NULL),
(30, 'jumlah_penduduk', '648', NULL, NULL),
(31, 'luas_wilayah', '4610 Ha', NULL, NULL),
(32, 'jumlah_dusun', '1', NULL, '2026-07-14 15:56:48'),
(33, 'visi', 'MENINGKATKAN TATA KELOLA PEMERINTAHAN DESA YANG BAIK DAN BERSIH GUNA MEWUJUDKAN DESA TALANG MARAP YANG ADIL, MAKMUR, SEJAHTERA DAN BERDASARKAN MUSYAWARAH MUFAKAT.', NULL, NULL),
(34, 'visi_deskripsi', 'Visi adalah suatu gambaran yang menantang tentang keadaan masa depan yang diinginkan dengan melihat potensi dan kebutuhan desa. Penyusunan visi Desa Talang Marap ini dilakukan dengan pendekatan partisipatif, melibatkan pihak-pihak yang berkepentingan di Desa Talang Marap seperti Pemerintah Desa, BPD, Tokoh Masyarakat, Tokoh Agama, lembaga masyarakat desa dan masyarakat desa pada umumnya.\r\n\r\nPertimbangan kondisi eksternal di desa seperti satuan kerja wilayah pembangunan di Kecamatan Kelam Tengah mempunyai titik berat sektor infrastruktur, maka berdasarkan pertimbangan di atas visi Desa Talang Marap yaitu:', NULL, NULL),
(35, 'misi', 'Mewujudkan pemerintah Desa yang tertib, aman, dan transparan\r\nMewujudkan pembangunan yang merata baik fisik dan pembangunan SDM\r\nMewujudkan perekonomian dan kesejahteraan masyarakat\r\nMewujudkan masyarakat yang berakhlak dan religious\r\nMewujudkan Masyarakat sehat\r\nMengaktifkan kegiatan kepemudaan\r\nMewujudkan kegiatan yang jujur, adil dan transparan', NULL, NULL),
(36, 'misi_deskripsi', 'Selain penyusunan visi juga telah ditetapkan misi-misi yang memuat suatu pernyataan yang harus dilaksanakan oleh warga Desa Talang Marap agar tercapainya visi Desa tersebut. Visi berada diatas misi. Pernyataan visi kemudian dijabarkan kedalam misi agar dapat dioperasionalkan/dikerjakan. Sebagaimana penyusunannya menggunakan pendekatan partisipatif dan pertimbangan potensi dan kebutuhan Desa Talang Marap sebagaimana proses yang dilakukan maka misi Desa Talang Marap yaitu:', NULL, NULL),
(37, 'sejarah_narasi', 'Desa Talang Marap merupakan salah satu Desa dalam Wilayah Administrasi Kecamatan Kelam Tengah yang terletak 3 KM dari sebelah Barat Kecamatan Kelam Tengah yang merupakan Desa hasil pemekaran dengan Desa Pagar Dewa Kecamatan Kelam Tengah Kabupaten Kaur pada tahun 2005.\r\n\r\nDiawal zaman penjajah Belanda sementara untuk kedudukan Kepemimpinan Desa atau Dusun dipimpin oleh Depati. Terdiri dari 2 Dusun yaitu Dusun Luuk Bingkok dan Dusun Tanjung Bunga. Pada masa Zaman kepemimpinan Depati Daerah Pagar Dewa masih dalam Zaman peperangan atau gerombolan, setelah selesai masa peperangan kedua Dusun tersebut bergabung menjadi sebuah kelompok dan terbentuk sebuah Desa yang dinamakan Desa Pagar Dewa.\r\n\r\nDesa Talang Marap diambil dari keyakinan Masyarakat terhadap dewa, maka dinamakan Talang Marap atau Dewa Pelindung pada tahun 1912. Yang pada masa itu untuk kepemimpinan dipegang oleh Depati Kaemajis, menjabat sebagai Depati dari tahun 1912 sampai dengan 1965.\r\n\r\nPada tahun selanjutnya dari tahun 1965 sampai dengan 1972 dipimpin oleh Depati Buyung Alinap, selepas tahun 1972 dengan peraturan baru yang dibuat oleh Pemerintah Republik Indonesia yang mentiadakan Wilayah Pasirah sebagai atasan Depati maka Depati menjadi Kepala Desa saat itu menjabat pertama dari tahun 1972 sampai dengan 1988 dipimpin oleh seorang Kepala Desa yang bernama Idris Ali, dan setelah habis masa jabatan Kepala Desa Talang Marap Idris Ali, digantikan oleh Irsanudin dari tahun 1988 sampai dengan tahun 1999. Pada akhir masa jabatan Irsanudin terjadi kekosongan kepemimpinan karena menunggu proses pemilihan kembali Kepala Desa sehingga kepemimpinan di Desa Talang Marap diambil alih oleh Kecamatan Kaur Utara yang bernama Yaswan.\r\n\r\nKemudian dari tahun 2000 sampai dengan Tahun 2006 Desa Pagar Dewa dipimpin oleh Justan, Kepemimpinan Justan hasil dari pemilihan Masyarakat Desa secara langsung. Setelah habis masa jabatan Kepala Desa Pagar Dewa Justan digantikan oleh Disirmin dari Tahun 2007 sampai dengan Tahun 2013. Pada masa pertengahan Kepala Desa Disirmin Tahun 2009 disaat Kabupaten Kaur memisahkan diri dari Kabupaten Bengkulu Selatan banyak pemekaran Kecamatan di Wilayah Kecamatan Kelam Tengah, sehingga terbentuklah Desa Talang Marap.\r\n\r\nSetelah terbentuknya Desa Talang Marap maka terpilih pemimpin desa atau Kepala Desa Talang Marap adalah Janusi A. Hamid dari tahun 2016 sampai dengan Tahun 2021 yang terpilih dari pemilihan Kepala Desa Talang Marap secara langsung oleh Masyarakat.\r\n\r\nPemimpin Desa atau Kepala Desa Talang Marap adalah Midarman. Dia terpilih dari pemilihan Kepala Desa Talang Marap secara langsung oleh Masyarakat. Midarman menjabat Kepala Desa dari tahun 2022 sampai tahun 2028.', NULL, NULL),
(38, 'geografi_batas_utara', 'Desa Talang Tais', NULL, NULL),
(39, 'geografi_batas_selatan', 'Desa Pagar Dewa', NULL, NULL),
(40, 'geografi_batas_barat', 'Desa Curup Air Putih', NULL, NULL),
(41, 'geografi_batas_timur', 'Seranjangan Besar', NULL, NULL),
(42, 'geografi_topografi', 'Secara umum keadaan Topografi Desa Talang Marap adalah merupakan daerah dataran rendah bergelombang.', NULL, NULL),
(43, 'geografi_iklim', 'Iklim Desa Talang Marap sebagaimana desa-desa lain di wilayah Indonesia mempunyai iklim kemarau dan penghujan. Hal ini mempunyai pengaruh langsung terhadap pola tanam yang ada di Desa Talang Marap Kecamatan Kelam Tengah Kabupaten Kaur.', NULL, NULL),
(44, 'geografi_luas_total', '6000', NULL, NULL),
(45, 'geografi_luas_pemukiman', '1000', NULL, NULL),
(46, 'geografi_luas_persawahan', '60', NULL, NULL),
(47, 'geografi_luas_perkebunan', '1300', NULL, NULL),
(48, 'geografi_luas_ladang', '1250', NULL, NULL),
(49, 'geografi_luas_lainnya', '1000', NULL, NULL),
(50, 'geografi_keluarga_miskin', '86', NULL, NULL),
(51, 'sejarah', NULL, NULL, '2026-07-14 15:56:48'),
(52, 'pekerjaan', NULL, NULL, '2026-07-14 15:56:48');

-- --------------------------------------------------------

--
-- Table structure for table `perangkat_desa`
--

CREATE TABLE `perangkat_desa` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `jabatan` varchar(255) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `foto` text DEFAULT NULL,
  `kontak` varchar(255) DEFAULT NULL,
  `urutan` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `perangkat_desa`
--

INSERT INTO `perangkat_desa` (`id`, `jabatan`, `nama`, `foto`, `kontak`, `urutan`, `created_at`, `updated_at`) VALUES
(1, 'Kepala Desa', 'Midarman', 'https://ui-avatars.com/api/?name=Midarman&background=2E7D32&color=fff&size=200', '081234567890', 1, '2026-07-14 01:55:20', '2026-07-14 01:55:20'),
(2, 'Sekretaris Desa', 'Dewi Lestari', 'https://ui-avatars.com/api/?name=Dewi+Lestari&background=43A047&color=fff&size=200', '081234567891', 2, '2026-07-14 01:55:20', '2026-07-14 01:55:20'),
(3, 'Bendahara Desa', 'Andi Kurniawan', 'https://ui-avatars.com/api/?name=Andi+Kurniawan&background=66BB6A&color=fff&size=200', '081234567892', 3, '2026-07-14 01:55:20', '2026-07-14 01:55:20'),
(4, 'Kepala Seksi Pemerintahan', 'Tresia Aprianti', 'https://ui-avatars.com/api/?name=Tresia+Aprianti&background=2E7D32&color=fff&size=200', '081234567893', 4, '2026-07-14 01:55:20', '2026-07-14 01:55:20'),
(5, 'Kepala Seksi Pembangunan', 'Budi Santoso', 'https://ui-avatars.com/api/?name=Budi+Santoso&background=43A047&color=fff&size=200', '081234567894', 5, '2026-07-14 01:55:20', '2026-07-14 01:55:20'),
(6, 'Kepala Seksi Kemasyarakatan', 'Rini Wulandari', 'https://ui-avatars.com/api/?name=Rini+Wulandari&background=81C784&color=fff&size=200', '081234567895', 6, '2026-07-14 01:55:20', '2026-07-14 01:55:20'),
(7, 'Kepala Dusun I', 'Hendra Putra', 'https://ui-avatars.com/api/?name=Hendra+Putra&background=2E7D32&color=fff&size=200', '081234567896', 7, '2026-07-14 01:55:20', '2026-07-14 01:55:20'),
(8, 'Kepala Dusun II', 'Yeni Marlina', 'https://ui-avatars.com/api/?name=Yeni+Marlina&background=43A047&color=fff&size=200', '081234567897', 8, '2026-07-14 01:55:20', '2026-07-14 01:55:20'),
(9, 'Ketua BPD', 'Hedi Satrio, SH', 'https://ui-avatars.com/api/?name=Hedi+Satrio&background=2E7D32&color=fff&size=200', '', 9, '2026-07-14 01:55:20', '2026-07-14 01:55:20'),
(10, 'Wakil Ketua BPD', 'Dopi Saputra', 'https://ui-avatars.com/api/?name=Tetap&background=43A047&color=fff&size=200', NULL, 10, '2026-07-14 01:55:20', '2026-07-14 16:12:43'),
(11, 'Sekretaris BPD', 'Kamli', 'https://ui-avatars.com/api/?name=Kamli&background=66BB6A&color=fff&size=200', '', 11, '2026-07-14 01:55:20', '2026-07-14 01:55:20'),
(12, 'Anggota BPD', 'Witra Habibi', 'https://ui-avatars.com/api/?name=Witra+Habibi&background=81C784&color=fff&size=200', '', 12, '2026-07-14 01:55:20', '2026-07-14 01:55:20'),
(13, 'Anggota BPD', 'Eva Pornamei', 'https://ui-avatars.com/api/?name=Eva+Pornamei&background=2E7D32&color=fff&size=200', '', 13, '2026-07-14 01:55:20', '2026-07-14 01:55:20');

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pesan_kontak`
--

CREATE TABLE `pesan_kontak` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nama` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `telepon` varchar(255) DEFAULT NULL,
  `subjek` varchar(255) DEFAULT NULL,
  `pesan` text NOT NULL,
  `sudah_dibaca` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `peta_rumah`
--

CREATE TABLE `peta_rumah` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `no_rumah` varchar(255) NOT NULL,
  `nama_kk` varchar(255) NOT NULL,
  `alamat` varchar(255) DEFAULT NULL,
  `rt` varchar(255) DEFAULT NULL,
  `rw` varchar(255) DEFAULT NULL,
  `dusun` varchar(255) DEFAULT NULL,
  `lat` decimal(10,7) NOT NULL,
  `lng` decimal(10,7) NOT NULL,
  `jumlah_jiwa` int(11) NOT NULL DEFAULT 1,
  `status_rumah` varchar(255) NOT NULL DEFAULT 'tetap',
  `keterangan` text DEFAULT NULL,
  `aktif` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `program_kerja`
--

CREATE TABLE `program_kerja` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nama` varchar(255) NOT NULL,
  `kategori` varchar(255) NOT NULL,
  `jenis` varchar(255) NOT NULL DEFAULT 'Program Kerja',
  `deskripsi` text NOT NULL,
  `tujuan` text DEFAULT NULL,
  `manfaat` text DEFAULT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'planned',
  `progress` int(11) NOT NULL DEFAULT 0,
  `target` varchar(255) DEFAULT NULL,
  `output` varchar(255) DEFAULT NULL,
  `tanggal_mulai` date DEFAULT NULL,
  `tanggal_selesai` date DEFAULT NULL,
  `pic` varchar(255) DEFAULT NULL,
  `icon` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `program_kerja`
--

INSERT INTO `program_kerja` (`id`, `nama`, `kategori`, `jenis`, `deskripsi`, `tujuan`, `manfaat`, `status`, `progress`, `target`, `output`, `tanggal_mulai`, `tanggal_selesai`, `pic`, `icon`, `created_at`, `updated_at`) VALUES
(2, 'Palang Petunjuk Jalan Kantor Desa', 'Umum', 'Program Kerja', 'Pembuatan dan pemasangan papan informasi petunjuk jalan menuju Kantor Desa Talang Marap. Sasaran program adalah pemerintah Desa Talang Marap.', 'Memberikan informasi kepada masyarakat terkait letak Kantor Desa Talang Marap.', 'Mempermudah masyarakat untuk mengetahui letak Kantor Desa Talang Marap.', 'completed', 100, 'Pendatang', 'Penunjuk Jalan', '2026-07-01', '2026-07-05', 'Muhammad Pin Ping', NULL, '2026-07-06 02:43:13', '2026-07-06 02:43:13');

-- --------------------------------------------------------

--
-- Table structure for table `statistik_desa`
--

CREATE TABLE `statistik_desa` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tahun` int(11) NOT NULL,
  `penduduk` int(11) NOT NULL DEFAULT 0,
  `kk` int(11) NOT NULL DEFAULT 0,
  `laki_laki` int(11) NOT NULL DEFAULT 0,
  `perempuan` int(11) NOT NULL DEFAULT 0,
  `umkm` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `statistik_desa`
--

INSERT INTO `statistik_desa` (`id`, `tahun`, `penduduk`, `kk`, `laki_laki`, `perempuan`, `umkm`, `created_at`, `updated_at`) VALUES
(1, 2020, 600, 190, 300, 300, 12, '2026-07-14 01:55:20', '2026-07-14 01:55:20'),
(2, 2021, 610, 194, 305, 305, 14, '2026-07-14 01:55:20', '2026-07-14 01:55:20'),
(3, 2022, 620, 198, 310, 310, 15, '2026-07-14 01:55:20', '2026-07-14 01:55:20'),
(4, 2023, 630, 202, 315, 315, 17, '2026-07-14 01:55:20', '2026-07-14 01:55:20'),
(5, 2024, 640, 207, 320, 320, 19, '2026-07-14 01:55:20', '2026-07-14 01:55:20'),
(6, 2025, 648, 211, 324, 324, 20, '2026-07-14 01:55:20', '2026-07-14 01:55:20');

-- --------------------------------------------------------

--
-- Table structure for table `umkm`
--

CREATE TABLE `umkm` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nama` varchar(255) NOT NULL,
  `kategori` varchar(255) NOT NULL,
  `foto` text DEFAULT NULL,
  `deskripsi` text NOT NULL,
  `harga` varchar(255) DEFAULT NULL,
  `kontak` varchar(255) DEFAULT NULL,
  `pemilik` varchar(255) DEFAULT NULL,
  `stok` varchar(255) DEFAULT NULL,
  `lokasi` varchar(255) DEFAULT NULL,
  `published` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(255) NOT NULL DEFAULT 'editor',
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `role`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Admin Desa', 'kkntalangmarap@gmail.com', '2026-06-28 00:41:37', '$2y$12$zYZpE1rLsarB7HMxxhQaXulm29SRKjDTv6j4xXykkj1WNOqjxt/cG', 'admin', NULL, '2026-06-23 03:42:26', '2026-07-06 01:57:12');

-- --------------------------------------------------------

--
-- Table structure for table `wisata`
--

CREATE TABLE `wisata` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nama` varchar(255) NOT NULL,
  `kategori` varchar(255) NOT NULL,
  `foto` text DEFAULT NULL,
  `deskripsi` text NOT NULL,
  `fasilitas` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL
) ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `agenda`
--
ALTER TABLE `agenda`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `anggota_kkn`
--
ALTER TABLE `anggota_kkn`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `aspirasi`
--
ALTER TABLE `aspirasi`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `berita`
--
ALTER TABLE `berita`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dokumen`
--
ALTER TABLE `dokumen`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `galeri`
--
ALTER TABLE `galeri`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pengaturan`
--
ALTER TABLE `pengaturan`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `pengaturan_key_unique` (`key`);

--
-- Indexes for table `perangkat_desa`
--
ALTER TABLE `perangkat_desa`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `pesan_kontak`
--
ALTER TABLE `pesan_kontak`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `peta_rumah`
--
ALTER TABLE `peta_rumah`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `program_kerja`
--
ALTER TABLE `program_kerja`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `statistik_desa`
--
ALTER TABLE `statistik_desa`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `umkm`
--
ALTER TABLE `umkm`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `agenda`
--
ALTER TABLE `agenda`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `anggota_kkn`
--
ALTER TABLE `anggota_kkn`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `aspirasi`
--
ALTER TABLE `aspirasi`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `berita`
--
ALTER TABLE `berita`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `dokumen`
--
ALTER TABLE `dokumen`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `galeri`
--
ALTER TABLE `galeri`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `pengaturan`
--
ALTER TABLE `pengaturan`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=54;

--
-- AUTO_INCREMENT for table `perangkat_desa`
--
ALTER TABLE `perangkat_desa`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pesan_kontak`
--
ALTER TABLE `pesan_kontak`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `peta_rumah`
--
ALTER TABLE `peta_rumah`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `program_kerja`
--
ALTER TABLE `program_kerja`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `statistik_desa`
--
ALTER TABLE `statistik_desa`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `umkm`
--
ALTER TABLE `umkm`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `wisata`
--
ALTER TABLE `wisata`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
